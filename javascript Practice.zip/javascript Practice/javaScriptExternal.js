/**
 * 
 */

function submission1(event){
	
	alert("okkk");
    //var v1=document.getElementById("uName").value;
    
    var name=document.getElementById("uName").value;
        
	if(name==''){
        alert("Name is Blank");
        
		event.preventDefault();
	}
	
}


function checkMob(){
	alert("======");
	//window.print();
	
	/*var response=confirm('Please confirm, your response?');//cancel and ok
	if(response){
		alert("=======111")
	}else{
		event.preventDefault();
	}*/
	
	//var response = prompt('What is your ID');
	//window.print();
	
	var mob=document.getElementById("mob").value;//we are assign value from html page to javascript variable
	
	if(isNaN(mob)){
		     document.getElementById("mob").style.borderColor="red"
			 document.getElementById("erMob").innerHTML="It shuld be a number";
	     
	}else{
		   document.getElementById("mob").style.borderColor="white"
				 document.getElementById("erMob").innerHTML=" ";
		  
	}
	
}

function submission(event){

	
	
	//window.print();
	
	/*var response = prompt('Enter your Age');
	if(response>18){
		
		
	}else{
		
		
	}
	alert(response);
	//var response=confirm('Do you want to submit the form');
	
	if(response){
		
		var name=document.getElementById("name").value;
		
		alert("true");
	}else{
		alert("false");
		event.preventDefault();
	}*/
	
	
	
	//var response = prompt('What is your option name?');
	//alert(response);
	
	
	
	/*var name=document.getElementById("name");
	if(name==''){
		event.preventDefault();
		
	}
	*/

	//window.print();
	/*var response = prompt('What is your option name?');

	var userName=document.getElementById("name").value;

	if(userName==''){
		alert("you are not allowed to submit");
		var response=confirm('Please confirm, your response?');
		if(response==true){
			alert("you pressed ok button");
		}else{
			alert("you pressed cancel");
			event.preventDefault();
		}*/
	//}
}

function sum(){

	//alert("ok");
    
	var num1=document.getElementById("num1").value;//22
	var num2=document.getElementById("num2").value;//4
    var re=parseInt(num1)+parseInt(num2);//22+4=26

   // var re=num1+num2;//
	//alert(re);
	document.getElementById("result").innerHTML=re;


}  

function Modulus(){
	var num2=document.getElementById("num2").value;
	var mod=parseInt(num2)%3;
	//example value 8%3=2
	if(mod==2){
		document.getElementById("result").innerHTML=mod;
	}else{
		document.getElementById("result").innerHTML="Sorry!";

	}

} 

function dialouge(){

	// window.print();
    //alert("Passive Alert box");
    /*
	var ar = [12,22,33,15];
	var st=12;
	var arSt = ["St1", "St2", "St3"];
	l=ar.length;
	l1=arSt.length;
	alert(l);
	alert(l1);
	for( i=0;i<l;i++){
		if((ar[i]==15)){
			alert(ar[i])//
		}
	}   
*/
    var response=confirm('Please confirm, your response?');
    
    var response = prompt('What is your option name?');
    
    
	alert(response);
} 

function cssHandle(){
	
//10 then only above two css will be changed
//15 then only font will applied
var response = prompt('What is your option name?');

if(response==10){
   document.getElementById("res").style.color = "blue";
   document.getElementById("res").style.backgroundColor="red";
   }
if(response==15){
       document.getElementById("err1").innerHTML="It Is Not A Number";
       document.getElementById("err1").style.color = "red";
       document.getElementById("num2").style.borderColor="red"
	   document.getElementById("res").style.font="italic bold 20px arial,serif";
	   }
//document.getElementById("pass").style.borderColor="red"
//document.getElementById("res").style.color = "blue";
//document.getElementById("res").style.backgroundColor="red";
//document.getElementById("res").style.font="italic bold 20px arial,serif";

}

function stringHandling(){
    var str = "we are in javascript as we are in ui/ux";
    

	var sln = str.length;
    var idx=str.indexOf("are");
    
	//alert("length="+sln);
	//alert("first index Of are= "+idx);
	var lIdx=str.lastIndexOf("are");
	//alert("Last index of are= "+lIdx);
	var fIndx=str.search("are");
	//alert(fIndx);
	
    var sliceStr=str.slice(3,11);
	alert("Slice of String is = "+sliceStr);
	 
	   var sliceStr=str.slice(-30);
	alert("Slice of String from reverse is = "+sliceStr);

	 var subSt=str.substr(3,3);
	alert("substring of string  = "+subSt);
	 
	  var newStr=str.replace("javascript","java");
	 alert("replaced string "+newStr);
	 alert("replaced string "+str);
	alert(newStr.toUpperCase());
	alert(newStr.toLowerCase());

	var s1="hi ";
	var s2="i am";
	var conStr=s1.concat(s2);
	//alert("concatination = " +conStr);
	//alert(s2.charAt(3));
	
	}
function dateHandling(){
	  var d = new Date();
	 // alert(d);
	  //alert(d.getDate());//
	  //alert(d.getMonth());
	  
	var days = ["Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"];
	
	
	 alert(d.getDay());
	 alert(days[d.getDay()]);
	 alert(d.getFullYear());
	/* alert(d.getDay());
	 alert(days[d.getDay()]);
	 alert(d.getMonth()+1);
	alert(d.getFullYear()); */
}//

function navigationPollicy(){
	alert("=====");
	var userName=document.getElementById("name").value;
    localStorage.setItem("loggedUser",userName);
    
    var rName=localStorage.getItem("loggedUser");
    
	   if(userName !='admin'){
		   window.location.href="bom.html";//welcome somnath
		   }else{
			   window.location.href="bootstrap1.jsp";
			   }
	}













